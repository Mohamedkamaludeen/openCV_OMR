package com.imageVisionPOC.springOpenCv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOpenCvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOpenCvApplication.class, args);
	}

}
